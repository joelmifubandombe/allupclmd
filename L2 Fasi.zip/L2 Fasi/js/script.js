/*var voirPlusButton = document.getElementById("voir-plus");
var blocsCaches = document.querySelectorAll(".hidden");

voirPlusButton.addEventListener("click", function() {
  for (var i = 0; i < blocsCaches.length; i++) {
    blocsCaches[i].classList.remove("hidden");
  }
  voirPlusButton.style.display = "none";
});

var searchIcon = document.getElementById('search-icon');
var searchInput = document.getElementById('search-input');

searchIcon.addEventListener('click', function() {
  if (searchInput.style.display === 'none') {
    searchInput.style.display = 'inline-block';
    searchInput.style.transition = 'opacity 1s';
    searchInput.style.opacity = '1';
    setTimeout(function() {
      searchInput.style.display = 'inline-block';
    }, 1000);
  } else {
    searchInput.style.opacity = '0';
    setTimeout(function() {
      searchInput.style.display = 'none';
    }, 300);
  }
});*/

